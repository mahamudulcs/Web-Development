#!/usr/bin/perl
use CGI ':standard';
print "Content-type: text/html\n\n";
print qq{
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="mystyle.css">
	</head>
	<body>
		<h1 class="textcolor">This is my first Perl program </h1>
	</body>
</html>
};